<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 2018/4/26
 * Time: 7:25
 */
interface SuperModuleInterface{
    public function activate(array $target);
}